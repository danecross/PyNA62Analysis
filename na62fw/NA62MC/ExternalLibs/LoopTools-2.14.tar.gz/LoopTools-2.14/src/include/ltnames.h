	character*6 paraname(Pee,1:5)
	common /ltparanames/ paraname

	character*10 coeffname(Nee,1:5)
	common /ltcoeffnames/ coeffname
